**momomo's Fantasy Chess RPG Character - Arthur**


Suitable for mobile Action RPG Games
Suitable for mobile Chess & Moba Games

Verts: 5043
Tris: 5978
Texture: 512X512 X 1
Icon: 128X128 X 1
Fx_Prefaps : 6

It have a 6 type animations
*Animation type_Generic (Not Humanoid)*
idle, walk, attack, active, passive, dead 




Thank you for your purchase!
If you have any questions mail me at 32d.artist@gmail.com


▼Check out momomo's other Assets▼
https://assetstore.unity.com/publishers/35389

▼Check out momomo's 'Fantasy Chess RPG Character Series'▼
https://assetstore.unity.com/?q=momomo%20Fantasy%20Chess%20RPG%20Character&orderBy=0